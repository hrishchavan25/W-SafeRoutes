// Dashboard.js
import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, Alert, ImageBackground } from "react-native";

export default function Dashboard({ route }) {
  // Get user data passed from login/signup
  const { name, email } = route.params || { name: "User", email: "" };

  const handleAction = (action) => {
    Alert.alert(action, `You clicked "${action}"`);
  };

  return (
    <ImageBackground
      source={{
        uri: "https://thumbs.dreamstime.com/b/close-up-trade-map-colorful-pins-marking-key-locations-close-up-trade-map-colorful-pins-marking-key-locations-353097520.jpg",
      }}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <Text style={styles.title}>Welcome, {name}!</Text>
        <Text style={styles.subtitle}>{email}</Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity
            style={styles.button}
            onPress={() => handleAction("Report Incident")}
          >
            <Text style={styles.buttonText}>Report Incident</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => handleAction("View Map")}
          >
            <Text style={styles.buttonText}>View Map</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.button}
            onPress={() => handleAction("Settings")}
          >
            <Text style={styles.buttonText}>Settings</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.3)",
  },
  title: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 18,
    color: "#fff",
    marginBottom: 30,
  },
  buttonContainer: {
    width: "85%",
  },
  button: {
    backgroundColor: "#2E8B8B",
    paddingVertical: 15,
    borderRadius: 10,
    marginBottom: 20,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
  },
});
