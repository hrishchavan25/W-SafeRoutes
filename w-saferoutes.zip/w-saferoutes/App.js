// App.js
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ImageBackground,
  StyleSheet,
  Alert,
} from "react-native";

// 🔹 Database setup placeholder (connect later via Firebase or firewall)
const connectToDatabase = () => {
  console.log("Database connection setup will go here");
};

export default function App() {
  const [isLogin, setIsLogin] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const handleSubmit = () => {
    // 🔹 Validation for both Login and Signup
    if (isLogin) {
      if (!email && !password) {
        Alert.alert("Missing Details", "Please enter your email and password.");
        return;
      } else if (!email) {
        Alert.alert("Missing Email", "Please enter your email address.");
        return;
      } else if (!password) {
        Alert.alert("Missing Password", "Please enter your password.");
        return;
      }

      connectToDatabase();
      Alert.alert("Welcome Back!", `Logged in as ${email}`);
    } else {
      if (!name && !email && !password && !confirmPassword) {
        Alert.alert("Missing Details", "Please fill in all fields to sign up.");
        return;
      } else if (!name) {
        Alert.alert("Missing Name", "Please enter your full name.");
        return;
      } else if (!email) {
        Alert.alert("Missing Email", "Please enter your email address.");
        return;
      } else if (!password) {
        Alert.alert("Missing Password", "Please set a password.");
        return;
      } else if (!confirmPassword) {
        Alert.alert("Missing Confirmation", "Please confirm your password.");
        return;
      } else if (password !== confirmPassword) {
        Alert.alert("Password Mismatch", "Passwords do not match!");
        return;
      }

      connectToDatabase();
      Alert.alert("Account Created", `Welcome, ${name}!`);
    }
  };

  return (
    <ImageBackground
      source={{
        uri: "https://cdn.wallpapersafari.com/77/71/4yx7lb.png",
      }}
      style={styles.background}
      resizeMode="cover"
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <Text style={styles.title}>W-SafeRoutes</Text>
          <Text style={styles.subtitle}>
            {isLogin
              ? "Welcome back! Sign in to stay protected."
              : "Join us in making the world safer for women."}
          </Text>

          {!isLogin && (
            <TextInput
              style={styles.input}
              placeholder="Full Name"
              placeholderTextColor="#fff"
              value={name}
              onChangeText={setName}
            />
          )}

          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#fff"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
          />
          <TextInput
            style={styles.input}
            placeholder="Password"
            placeholderTextColor="#fff"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          {!isLogin && (
            <TextInput
              style={styles.input}
              placeholder="Confirm Password"
              placeholderTextColor="#fff"
              value={confirmPassword}
              onChangeText={setConfirmPassword}
              secureTextEntry
            />
          )}

          <TouchableOpacity style={styles.button} onPress={handleSubmit}>
            <Text style={styles.buttonText}>
              {isLogin ? "Login" : "Sign Up"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setIsLogin(!isLogin)}>
            <Text style={styles.switchText}>
              {isLogin
                ? "Don’t have an account? Sign up"
                : "Already have an account? Log in"}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: {
    flex: 1,
  },
  overlay: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
  container: {
    backgroundColor: "rgba(255, 255, 255, 0.25)",
    padding: 30,
    borderRadius: 20,
    width: "85%",
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 3 },
    shadowRadius: 4,
  },
  title: {
    fontSize: 34,
    fontWeight: "800",
    color: "#fff",
    marginBottom: 10,
  },
  subtitle: {
    color: "#fff",
    textAlign: "center",
    fontSize: 20,
    marginBottom: 25,
  },
  input: {
    width: "100%",
    padding: 12,
    borderWidth: 1,
    borderColor: "#fff",
    borderRadius: 8,
    marginBottom: 15,
    color: "#fff",
  },
  button: {
    backgroundColor: "#2E8B8B",
    paddingVertical: 12,
    paddingHorizontal: 50,
    borderRadius: 8,
    marginTop: 10,
  },
  buttonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 18,
  },
  switchText: {
    color: "#fff",
    marginTop: 20,
    fontSize: 20,
    textDecorationLine: "underline",
  },
});