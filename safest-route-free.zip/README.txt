Safest Route — Free Stack (ORS + Leaflet + Overpass)

1) Replace YOUR_ORS_API_KEY in index.html with your free OpenRouteService API key:
   https://openrouteservice.org/sign-up/
2) Run the Maven project in IntelliJ or via `mvn javafx:run`.
3) Click map to set Start & End in Andheri, Mumbai, then click "Compute Route".
4) The walking route will appear, and police stations are marked via Overpass API.

Notes:
- No billing required, completely free for academic demo.
- Safety scoring is basic: number of police stations near the route.
- For large-scale or production, consider self-hosting ORS or Overpass.
